/*
    Write code in the space provided so that the expected values output
*/

var dog = {
    name: 'Billy',
    wantsToPlay: false
};

// WRITE CODE HERE
var dog = {
    name: "Rex",
    wantsToPlay: true
};

//DO NOT MODIFY BELOW
console.log(dog.name);
console.log(dog.wantsToPlay);

// it should output:
// Rex
// true