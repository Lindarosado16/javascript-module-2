/*
    Write code in the space provided so that it outputs "Gilbert"
*/

// WRITE CODE HERE

var kitten = {
    name: "Gilbert",
    
};

console.log(kitten.name);

// -> it should output: "Gilbert"