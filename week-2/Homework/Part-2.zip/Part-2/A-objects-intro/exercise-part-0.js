/*

Describe your own laptop as a JavaScript object

Try to think of as many properties as you can!

*/

let laptop = {
    brand: "Macbook",
    screenSize: 13,
    isTouchscreen: true,
    model: "Pro",
    color: "plata"
  };