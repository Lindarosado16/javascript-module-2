/*

The objects below have some syntax issues - try and fix them all!

*/

var kitten = {
    furColour: "orange",
    age:"23"
};

var laptop = {
    brand: "Lenovo",
    ram:"5GB"
};

var phone = {
    operatingSystem: "iOS",
    hasStylus: "true",
    megapixels: "12",
    batteryLife: "24 hours"

}