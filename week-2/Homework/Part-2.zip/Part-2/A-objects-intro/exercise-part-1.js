/*

Think of 5 different real world "things" that you 
can describe with a JavaScript object

Assign each of them to a separate variable


For example:
var car = {
    brand: "Seat",
    model: "Arona",
    color: "white",
    horsepower: 115,
    doors: 5
};

*/

const student = {
    Name: "Linda",
    Lastname: "Rosado",
    Age: "26"
};

const movil = {
    Brand: "Apple",
    model: "11 pro max",
    color: "Black"
};

const favoriteFood = {
    type: "Venezolana and Peruana",
    food: "Arepa and ceviche"
};

const teacher = {
    Name: "Eduard",
    Lastname: "Haff"

};

const cars = {
    Brand: "toyota",
    model: "Yaris"
};
